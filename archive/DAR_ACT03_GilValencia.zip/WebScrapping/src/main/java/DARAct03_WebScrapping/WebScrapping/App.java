package DARAct03_WebScrapping.WebScrapping;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.*;

public class App {
	
	public static final String url = "https://www.verema.com/foros/hosteleria/temas?page=%s&tab=foros";
	public static final int maxPages = 6;
	
    public static void main( String[] args ) throws Exception{
    
    	PrintWriter out = new PrintWriter(new FileWriter("D:\\outScrapping.html"));
    	
    	int numPagina = 0;
    	int numeroEntradas = 0;
    	
    	for (int i=1; i<maxPages; i++){
    		Thread.sleep(1000);
    		
    		String urlPage = String.format(url, i);
         
    		//---------------------------------------------------------------
    		//System.out.println("Comprobando entradas de: "+urlPage+"\n");
    		//out.println("<br>Comprobando entradas de: "+urlPage+"<br>");
    		//---------------------------------------------------------------
    		
            numPagina = i;
       
            // Compruebo si me da un 200 al hacer la petición
            if (getStatusConnectionCode(urlPage) == 200) {
            	
            	// Obtengo el HTML de la web en un objeto Document
                Document document = getHtmlDocument(urlPage);
            	
                // Busco todas las entradas que estan dentro de: 
               
                Elements temas = document.select("table.temas");
                Elements trs = temas.select("tr");
          
                Elements h5 = temas.select("h5");
                
                //---------------------------------------------------------------
                System.out.println("\t-->>PAGINA "+numPagina+"<<--");
                out.println("<dd>/////////////////////////////////////////////////////////////////////////////////////////////////</dd><br>");
                out.println("<dd>_________________________________________________________________________________________________</dd><br>");
                out.println("<dd>-->>PAGINA "+numPagina+"<<--</dd>");
                System.out.println("-Número de entradas en página "+numPagina+": "+h5.size()+"\n");
                out.println("<br>-Número de entradas en página "+numPagina+": "+h5.size()+"<br>");
                //---------------------------------------------------------------
                
                // Paseo cada una de las entradas
                for (Element elem : trs) {
                	Elements entradas = elem.select("h5");
                
                	if(entradas.size() > 0) {
                		Elements elems = entradas.select("a");
                    	Element a1 = elems.get(0);
                    	String enlace = a1.absUrl("href");
                    	String titulo = a1.getElementsByTag("a").text();
                    	String autor = elem.getElementsByClass("forum-page-user-nick").text();
                    	
                    	//---------------------------------------------------------------
                    	System.out.println("TITULO: "+titulo+"\nAUTOR: "+autor+"\nENLACE: "+enlace+"\n");
                    	out.println("<br>TITULO: "+titulo+"<br>AUTOR: "+autor+"<br>ENLACE: "+enlace+"<br><br>");
                    	//---------------------------------------------------------------
                    	
                    	/*
                    	 * DEJO COMENTADO EL QUE FUERA METODO PARA RECORRER CADA POST "posts(enlace)".
                    	 * Al realizar dicho contenido dentro de cada post, para ver sus hilos, lo deseché,
                    	 * pero su contenido se incluye en las siguientes lineas.
                    	 */
                    	//posts(enlace);
                    	
                    	Document doc = Jsoup.connect(enlace).get();
                    	
                    	Elements mainContent = doc.select("article.core-Thread");
                		Elements header = mainContent.select("header");
                		Element header01 = header.get(0);
                		String title = header01.getElementsByClass("core-Thread_Heading").text();
                		
                		Elements respuestas = mainContent.select("div.core-ContainerInHalves_HalfLeft");
                		Elements span = respuestas.select("span");
                		Element res = span.get(0);
                		String respuesta = res.getElementsByTag("span").text();
                		
                		//---------------------------------------------------------------
                		System.out.println("\tTITULO: "+title+"\n\tRESPUESTAS: "+respuesta+"\n");
                		out.println("<dd>TITULO: "+title+"<br>RESPUESTAS: "+respuesta+"</dd><br>");
                		//---------------------------------------------------------------
                    	
                		Elements forosDebate = mainContent.select("div.foros_de_debate");
                		Elements foros = forosDebate.select("article.core-Post");
                		for(Element elemento : foros) {
                			Elements numero = elemento.select("div.core-Spacer-top-medium");
                			Elements numeroA = numero.select("a");
                			Element numero01 = numeroA.get(0);
                			String numeroPost = numero01.getElementsByTag("a").text();
                			
                			Elements auto = elemento.select("a.core-UserPane_Username");
                			Elements autorA = auto.select("span");
                			Element autor01 = autorA.get(0);
                			String autorPost = autor01.getElementsByTag("span").text();
                			
                			String fechaPost = elemento.getElementsByTag("time").text();
                			
                			//---------------------------------------------------------------
                			System.out.println("\t-Post "+numeroPost+"\n\t-Autor: "+autorPost+"\n\t-Fecha: "+fechaPost);
                			out.println("<dd>-Post "+numeroPost+"<br>-Autor: "+autorPost+"<br>-Fecha: "+fechaPost+"</dd><br>");
                			//---------------------------------------------------------------
                			
                			Elements contenido = elemento.select("div.core-PostMessage");
                			Elements contenidoA = contenido.select("main");
                			Elements parrafos = contenidoA.select("p");
                			
                			//---------------------------------------------------------------
                			System.out.println("\t-Contenido:");
                			out.println("<dd>-Contenido:</dd><br>");
                			//---------------------------------------------------------------
                			
                			for(Element parrafo : parrafos) {
                				String contenidoPost = parrafo.getElementsByTag("p").text();
                				//---------------------------------------------------------------
                				System.out.println("\t\t-"+contenidoPost);
                				out.println("<dd><p>-"+contenidoPost+"</p></dd>");
                				//---------------------------------------------------------------
                			}
                			//---------------------------------------------------------------
                			System.out.println("\n");
                			out.println("<br>");
                			
                			//---------------------------------------------------------------
                		}
                		
                    	/*
                    	 * Esta parte comentada es para hacer un bucle
                    	 * de todas las páginas de cada hilo.
                    	 * Debido al error 429 de sobresaturación de peticiones lo tuve que obviar.
                    	 * Pero para dar constancia de haberlo hecho, lo dejo comentado en este código.
                    	 */
                    	
                    	/*
                    	int variable = 1;
                    	String enlacePage = enlace.substring(0, enlace.length()-variable);
                    	
                    	for(int j=1; j<20; j++) {
                    		String enlaceCompleto = String.format(enlacePage+j, j);
                    		//Document doc = getHtmlDocument(enlaceCompleto);
                    		Document doc = Jsoup.connect(enlaceCompleto).get();
                    		Elements corePost = doc.select("article.core-Post");
                    		if(corePost.size() > 0) {
                    			//System.out.println(enlaceCompleto);
                    			
                            		Elements mainContent = doc.select("article.core-Thread");
                            		Elements header = mainContent.select("header");
                            		Element header01 = header.get(0);
                            		String title = header01.getElementsByClass("core-Thread_Heading").text();
                            		
                            		Elements respuestas = mainContent.select("div.core-ContainerInHalves_HalfLeft");
                            		Elements span = respuestas.select("span");
                            		Element res = span.get(0);
                            		String respuesta = res.getElementsByTag("span").text();
                            	
                            		//---------------------------------------------------------------
                            		System.out.println("\tTITULO: "+title+"\n\tRESPUESTAS: "+respuesta+"\n");
                            		out.println("<dd>TITULO: "+title+"__PAGINA: "+j+"<br>RESPUESTAS: "+respuesta+"</dd><br>");
                            		//---------------------------------------------------------------
                            		
                            		Elements forosDebate = mainContent.select("div.foros_de_debate");
                            		Elements foros = forosDebate.select("article.core-Post");
                            		for(Element elemento : foros) {
                            			Elements numero = elemento.select("div.core-Spacer-top-medium");
                            			Elements numeroA = numero.select("a");
                            			Element numero01 = numeroA.get(0);
                            			String numeroPost = numero01.getElementsByTag("a").text();
                            			
                            			Elements auto = elemento.select("a.core-UserPane_Username");
                            			Elements autorA = auto.select("span");
                            			Element autor01 = autorA.get(0);
                            			String autorPost = autor01.getElementsByTag("span").text();
                            			
                            			String fechaPost = elemento.getElementsByTag("time").text();
                            			
                            			//---------------------------------------------------------------
                            			System.out.println("\t-Post "+numeroPost+"\n\t-Autor: "+autorPost+"\n\t-Fecha: "+fechaPost);
                            			out.println("<dd>-Post "+numeroPost+"<br>-Autor: "+autorPost+"<br>-Fecha: "+fechaPost+"</dd><br>");
                            			//---------------------------------------------------------------
                            			
                            			Elements contenido = elemento.select("div.core-PostMessage");
                            			Elements contenidoA = contenido.select("main");
                            			Elements parrafos = contenidoA.select("p");
                            			
                            			//---------------------------------------------------------------
                            			System.out.println("\t-Contenido:");
                            			out.println("<dd>-Contenido:</dd><br>");
                            			//---------------------------------------------------------------
                            			
                            			for(Element parrafo : parrafos) {
                            				String contenidoPost = parrafo.getElementsByTag("p").text();
                            				//---------------------------------------------------------------
                            				System.out.println("\t\t-"+contenidoPost);
                            				out.println("<dd><dd>-"+contenidoPost+"</dd></dd>");
                            				//---------------------------------------------------------------
                            			}
                            			//---------------------------------------------------------------
                            			System.out.println("\n");
                            			out.println("<br>");
                            			
                            			//---------------------------------------------------------------
                            		}
                            	
                    		}
                    	}*/
                	}
                	
                	numeroEntradas = numeroEntradas + entradas.size();
               
                }
            }	
            else {
           	 System.out.println("El Status Code no es OK es: "+getStatusConnectionCode(url));
           	 out.println("El Status Code no es OK es: "+getStatusConnectionCode(url));
           }
           
    	}
    	//---------------------------------------------------------------
    	System.out.println("_________________________________________________________");
    	out.println("<dd>_________________________________________________________</dd><br>");
    	System.out.println("-->>NUMERO TOTAL DE ENTRADAS EN FORO : "+numeroEntradas+"<<--\n");
    	out.println("<dd>-->>NUMERO TOTAL DE ENTRADAS EN FORO : "+numeroEntradas+"<<--</dd><br><br>");
    	//---------------------------------------------------------------
    	
    	out.close();
    }
    
    /*
     * Método para obtener los posts insternos de cada hilo del foro.
     */
    
    public static void posts(String enlace) throws Exception{
    	
    	try {
    		Document doc = Jsoup.connect(enlace).get();
    		
    		Elements mainContent = doc.select("article.core-Thread");
    		Elements header = mainContent.select("header");
    		Element header01 = header.get(0);
    		String title = header01.getElementsByClass("core-Thread_Heading").text();
    		
    		Elements respuestas = mainContent.select("div.core-ContainerInHalves_HalfLeft");
    		Elements span = respuestas.select("span");
    		Element res = span.get(0);
    		String respuesta = res.getElementsByTag("span").text();
    	
    		//---------------------------------------------------------------
    		System.out.println("\tTITULO: "+title+"\n\tRESPUESTAS: "+respuesta+"\n");
    		//out.println("<dd>TITULO: "+titulo+"<br>RESPUESTAS: "+respuesta+"</dd><br>");
    		//---------------------------------------------------------------
    		
    		Elements forosDebate = mainContent.select("div.foros_de_debate");
    		Elements foros = forosDebate.select("article.core-Post");
    		for(Element elemento : foros) {
    			Elements numero = elemento.select("div.core-Spacer-top-medium");
    			Elements numeroA = numero.select("a");
    			Element numero01 = numeroA.get(0);
    			String numeroPost = numero01.getElementsByTag("a").text();
    			
    			Elements auto = elemento.select("a.core-UserPane_Username");
    			Elements autorA = auto.select("span");
    			Element autor01 = autorA.get(0);
    			String autorPost = autor01.getElementsByTag("span").text();
    			
    			String fechaPost = elemento.getElementsByTag("time").text();
    			
    			//---------------------------------------------------------------
    			System.out.println("\t-Post "+numeroPost+"\n\t-Autor: "+autorPost+"\n\t-Fecha: "+fechaPost);
    			
    			//---------------------------------------------------------------
    			
    			Elements contenido = elemento.select("div.core-PostMessage");
    			Elements contenidoA = contenido.select("main");
    			Elements parrafos = contenidoA.select("p");
    			
    			//---------------------------------------------------------------
    			System.out.println("\t-Contenido:");
    			//---------------------------------------------------------------
    			
    			for(Element parrafo : parrafos) {
    				String contenidoPost = parrafo.getElementsByTag("p").text();
    				//---------------------------------------------------------------
    				System.out.println("\t\t-"+contenidoPost);
    				
    				//---------------------------------------------------------------
    			}
    			//---------------------------------------------------------------
    			System.out.println("\n");
    			
    			//---------------------------------------------------------------
    		}
    		
    	} 
    	catch (IOException ex) {
    		
    	}
    	
    }
    
    
    /**
     * __________________________________________________________________________________
     * Con este método devuelvo un objeto de la clase Document con el contenido del
     * HTML de la web que me permitirá parsearlo con los métodos de la librelia JSoup
     * @param url
     * @return Documento con el HTML
     */
    
    public static Document getHtmlDocument(String url) {

        Document doc = null;
    	try {
    	    doc = Jsoup.connect(url).userAgent("Mozilla/5.0").timeout(100000).get();
    	    } catch (IOException ex) {
    		System.out.println("Excepción al obtener el HTML de la página" + ex.getMessage());
    	    }
        return doc;
    }
    
    /**
     * ____________________________________________________________________________________
     * Con esta método compruebo el Status code de la respuesta que recibo al hacer la petición
     * EJM:
     * 		200 OK			300 Multiple Choices
     * 		301 Moved Permanently	305 Use Proxy
     * 		400 Bad Request		403 Forbidden
     * 		404 Not Found		500 Internal Server Error
     * 		502 Bad Gateway		503 Service Unavailable
     * @param url
     * @return Status Code
     */
    public static int getStatusConnectionCode(String url) {
    		
        org.jsoup.Connection.Response response = null;
    	
        try {
        	response = Jsoup.connect(url).userAgent("Mozilla/5.0").timeout(100000).ignoreHttpErrors(true).execute();
        } 
        catch (IOException ex) {
        	System.out.println("Excepción al obtener el Status Code: " + ex.getMessage());
        }
        return response.statusCode();
    }
    
}
